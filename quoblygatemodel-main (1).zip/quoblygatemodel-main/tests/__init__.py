"""
Initialize the test package for pytest.
Allows relative imports inside tests.
"""
