spin\_pulse.noise package
=========================

Submodules
----------

spin\_pulse.noise.coherent module
---------------------------------

.. automodule:: spin_pulse.noise.coherent
   :members:
   :show-inheritance:
   :undoc-members:

spin\_pulse.noise.pink module
-----------------------------

.. automodule:: spin_pulse.noise.pink
   :members:
   :show-inheritance:
   :undoc-members:

spin\_pulse.noise.white module
------------------------------

.. automodule:: spin_pulse.noise.white
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: spin_pulse.noise
   :members:
   :show-inheritance:
   :undoc-members:
