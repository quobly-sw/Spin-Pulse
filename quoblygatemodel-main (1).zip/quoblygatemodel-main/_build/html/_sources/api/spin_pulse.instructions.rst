spin\_pulse.instructions package
================================

Submodules
----------

spin\_pulse.instructions.idle module
------------------------------------

.. automodule:: spin_pulse.instructions.idle
   :members:
   :show-inheritance:
   :undoc-members:

spin\_pulse.instructions.rotations module
-----------------------------------------

.. automodule:: spin_pulse.instructions.rotations
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: spin_pulse.instructions
   :members:
   :show-inheritance:
   :undoc-members:
